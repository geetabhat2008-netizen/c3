'use client'

import { useState } from 'react'
import { motion, useReducedMotion, AnimatePresence } from 'framer-motion'

/* ------------------------------------------------------------------ */
/*  DATA                                                              */
/* ------------------------------------------------------------------ */

const FAQS = [
  {
    q: 'Can I use it during an attack?',
    a: 'Yes — that is exactly what it is built for. Every module operates silently and in complete darkness. No screens, no app required mid-attack, no bright status lights.',
  },
  {
    q: 'How is this different from a massage gun or an ice hat?',
    a: 'Those address one mechanism. A migraine attack involves five — vascular pressure, photophobia, thermal dysregulation, phonophobia, and cervical tension. The Suite is the only system designed to cover all five at once.',
  },
  {
    q: 'What if it does not work for me?',
    a: 'Follow the protocol for 30 days. If you experience no meaningful reduction in sensory burden, we issue a full refund. We guarantee the system — not just the hardware.',
  },
  {
    q: 'Is it really a one-time purchase?',
    a: 'Yes. $345, once. No subscription, no refills, no consumables. Every module is rechargeable and built to last years, not months.',
  },
  {
    q: 'Can I pay with HSA or FSA funds?',
    a: 'Yes — the Suite is HSA / FSA eligible. Using pre-tax health dollars, the effective post-tax cost for most users is under $260.',
  },
  {
    q: 'How long does shipping take?',
    a: 'Orders ship within 24 hours. Delivery is 3–5 business days in the US. The Sanctuary Protocol ebook is delivered instantly by email.',
  },
]

/* ------------------------------------------------------------------ */
/*  COMPONENT                                                         */
/* ------------------------------------------------------------------ */

export default function FaqSection() {
  const reduce = useReducedMotion()
  const [open, setOpen] = useState<number | null>(0)

  const fadeUp = (delay = 0) => ({
    initial: reduce ? false : { opacity: 0, y: 14 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: '-40px' },
    transition: reduce
      ? { duration: 0 }
      : { duration: 0.55, delay, ease: 'easeOut' as const },
  })

  return (
    <section id="faq" className="faq has-grid-rules" aria-labelledby="faq-heading">
      <div className="faq__inner">
        {/* Header */}
        <motion.div className="faq__header" {...fadeUp(0)}>
          <p className="faq__eyebrow">Common Questions</p>
          <h2 id="faq-heading" className="faq__title text-balance">
            <span className="faq__title-line">Before you decide,</span>
            <span className="faq__title-line faq__title-line--accent">
              ask us anything.
            </span>
          </h2>
        </motion.div>

        {/* Accordion */}
        <div className="faq__list">
          {FAQS.map((item, i) => {
            const isOpen = open === i
            return (
              <motion.div key={item.q} className="faq__item" {...fadeUp(0.08 + i * 0.05)}>
                <h3 className="faq__q-wrap">
                  <button
                    type="button"
                    className="faq__q"
                    aria-expanded={isOpen}
                    aria-controls={`faq-panel-${i}`}
                    id={`faq-trigger-${i}`}
                    onClick={() => setOpen(isOpen ? null : i)}
                  >
                    <span className="faq__q-text">{item.q}</span>
                    <span className={`faq__icon ${isOpen ? 'faq__icon--open' : ''}`} aria-hidden="true">
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                        <path d="M6 1v10M1 6h10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
                      </svg>
                    </span>
                  </button>
                </h3>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={`faq-panel-${i}`}
                      role="region"
                      aria-labelledby={`faq-trigger-${i}`}
                      initial={reduce ? { height: 'auto' } : { height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={reduce ? { height: 'auto' } : { height: 0, opacity: 0 }}
                      transition={reduce ? { duration: 0 } : { duration: 0.32, ease: [0, 0, 0.2, 1] }}
                      style={{ overflow: 'hidden' }}
                    >
                      <p className="faq__a">{item.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )
          })}
        </div>

        {/* Footer note */}
        <motion.p className="faq__note" {...fadeUp(0.4)}>
          Still unsure? Write to us at{' '}
          <a href="mailto:care@crowncalm.com" className="faq__link">
            care@crowncalm.com
          </a>{' '}
          — a human replies within 24 hours.
        </motion.p>
      </div>

      <style jsx>{`
        .faq {
          position: relative;
          background: var(--color-bg);
          padding: clamp(48px, 6.5vw, 84px) max(46px, 5.5vw);
        }
        .faq__inner {
          position: relative;
          z-index: 1;
          max-width: 720px;
          margin: 0 auto;
        }

        /* ---------- header ---------- */
        .faq__header {
          margin-bottom: 36px;
        }
        .faq__eyebrow {
          font-family: var(--font-mono);
          font-size: 11px;
          font-weight: 400;
          letter-spacing: 0.16em;
          text-transform: uppercase;
          color: #8f8981;
          margin: 0 0 16px;
        }
        .faq__title {
          font-family: var(--font-display);
          font-size: clamp(30px, 4vw, 46px);
          font-weight: 400;
          line-height: 1.08;
          letter-spacing: -0.03em;
          margin: 0;
        }
        .faq__title-line {
          display: block;
          color: var(--color-text-primary);
        }
        .faq__title-line--accent {
          font-style: italic;
          color: #c4503a;
        }

        /* ---------- list ---------- */
        .faq__list {
          border-top: 1px solid rgba(26, 26, 26, 0.12);
        }
        .faq__item {
          border-bottom: 1px solid rgba(26, 26, 26, 0.12);
        }
        .faq__q-wrap {
          margin: 0;
        }
        .faq__q {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          padding: 18px 2px;
          background: none;
          border: none;
          cursor: pointer;
          text-align: left;
        }
        .faq__q:focus-visible {
          outline: 2px solid #1a1a1a;
          outline-offset: 2px;
        }
        .faq__q-text {
          font-family: var(--font-display);
          font-size: 16.5px;
          font-weight: 400;
          letter-spacing: -0.01em;
          line-height: 1.4;
          color: var(--color-text-primary);
        }
        .faq__icon {
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 26px;
          height: 26px;
          border: 1px solid rgba(26, 26, 26, 0.2);
          border-radius: 50%;
          color: #1a1a1a;
          transition: transform 0.25s ease, background 0.2s ease;
        }
        .faq__icon--open {
          transform: rotate(45deg);
          background: #1a1a1a;
          color: #f2ece4;
          border-color: #1a1a1a;
        }
        .faq__a {
          font-family: var(--font-body);
          font-size: 15.5px;
          line-height: 1.6;
          letter-spacing: 0;
          color: #5c5c5c;
          max-width: 600px;
          margin: 0;
          padding: 0 40px 20px 2px;
        }

        /* ---------- note ---------- */
        .faq__note {
          font-family: var(--font-body);
          font-size: 14.5px;
          letter-spacing: 0;
          line-height: 1.6;
          color: #6b655d;
          margin: 28px 0 0;
        }
        .faq__link {
          color: var(--color-text-primary);
          text-decoration: none;
          border-bottom: 1px solid rgba(26, 26, 26, 0.3);
          padding-bottom: 1px;
        }
        .faq__link:hover {
          border-bottom-color: #1a1a1a;
        }

        /* ---------- mobile ---------- */
        @media (max-width: 640px) {
          .faq__q-text {
            font-size: 15px;
          }
          .faq__a {
            padding-right: 12px;
          }
        }
      `}</style>
    </section>
  )
}
